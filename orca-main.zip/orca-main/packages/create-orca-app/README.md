# Create Orca App

This package includes the CLI tool to make the creation of an Orca app easy. It is published as a `create-orca-app` on [NPM](create-orca-app).

### How to use

Using NPX

```
npx create-orca-app my-app
```

Using Yarn create command

```
yarn create orca-app my-app
```
