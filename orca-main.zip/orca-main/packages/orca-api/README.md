# Orca API

Orca API built with the [Node.js](https://nodejs.org) framework [Express.js](https://expressjs.com).

### Running the app in development mode

```
yarn dev
```

### Building the app

```
yarn build
```

### Running the app in production mode

```
yarn start
```
