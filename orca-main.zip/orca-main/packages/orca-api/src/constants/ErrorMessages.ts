export enum ErrorMessages {
  Generic = 'Oops! Something went wrong. Please send an error report to help us improve your experience.',
}
