export enum ErrorCodes {
  Bad_Request = 400,
  Un_Authorized = 401,
  Not_Found = 404,
  Internal = 500,
}
