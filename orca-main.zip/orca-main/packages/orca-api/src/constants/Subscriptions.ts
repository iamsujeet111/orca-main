export enum Subscriptions {
  Message_Created = 'MESSAGE_CREATED',
  Is_User_Online = 'IS_USER_ONLINE',
  New_Conversation = 'NEW_CONVERSATION',
  Notification_Created_Or_Deleted = 'NOTIFICATION_CREATED_OR_DELETED',
}
