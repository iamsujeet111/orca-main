export { default } from './AuthPopup';
