export { default } from './GlobalStyle';
