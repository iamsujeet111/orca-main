export { default } from './TextAreaAutoSize';
