export { default } from './UploadImage';
