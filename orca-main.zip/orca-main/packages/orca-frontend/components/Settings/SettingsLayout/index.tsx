export { default } from './SettingsLayout';
