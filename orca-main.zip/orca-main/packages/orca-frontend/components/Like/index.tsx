export { default } from './Like';
