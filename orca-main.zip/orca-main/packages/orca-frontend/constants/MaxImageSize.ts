export const MaxImageSize = {
  Post: 3000000,
};
