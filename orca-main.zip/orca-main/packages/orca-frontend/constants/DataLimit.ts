export const DataLimit = {
  PostsByFollowing: 6,
  PostsByChannelName: 6,
  PostsByAuthorId: 6,
  Members: 40,
  AdminUsers: 40,
};
